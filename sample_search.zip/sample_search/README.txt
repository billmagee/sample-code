HMS People Search module
================================================================================
Created by:
Bill Magee - 12/05/20xx

This is a custom module that searches directories for staff and faculty.

Sample Search: Provides integration with Staff and Faculty directory and will return
results for Alumni and Faculty which are displayed as two separate sections of
results, Alumni results followed by Faculty results.

Installation
--------------------------------------------------------------------------------
Install as usual.

Place the entirety of this directory in the /modules/custom folder of your
Drupal installation. Navigate to Administer > Extend. Check the 'Enabled' box
next to the 'Admin toolbar' and/or 'Admin toolbar Extra Tools' and then click
the 'Save Configuration' button at the bottom.

For help regarding installation, visit:
https://www.drupal.org/documentation/install/modules-themes/modules-8

Configuration Settings
--------------------------------------------------------------------------------
Global Settings
  - Maximum Number of Search Results: 25
  - Maximum Results to Display: 5

HMS Directory
  - Endpoint:https://some-endpoint-url/service.asmx/
  - Appid: SomeAppID
  - Directory IP Address: xxx.xxx.xxx.xx
  - User ID: SomeUserID
  - Password: SomePassword

Setup
--------------------------------------------------------------------------------
This module will automatically create a page and a block:
  Page URL  : /sample-search
  Block Name: SampleSearch

Take the following steps to setup the block:
  1. Login as an admin and click on Block Layout under Structure
  2. Scroll down to the "Left Sidebar" section and click on Place block
  3. Use the filter to find the Sample Search block
  4. Click on Place block
  5. In the block configuration, click on Pages under Visibility
  6. Enter the following in the text are: /sample-search*
  7. Select "Show for listed pages"
  8. Uncheck Display title
  9. Save your changes
 10. Add an option to the appropriate menu for Directory Search
