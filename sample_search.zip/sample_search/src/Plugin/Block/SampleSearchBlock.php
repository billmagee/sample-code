<?php

namespace Drupal\sample_search\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a Sample Search Block.
 *
 * @Block(
 *   id = "sample_search_block",
 *   admin_label = @Translation("Directory Search"),
 *   category = @Translation("Directory Search"),
 * )
 */
class SampleSearchBlock extends BlockBase implements BlockPluginInterface {

  /**
   * {@inheritdoc}
   */
  public function build() {
    $form = \Drupal::formBuilder()->getForm('Drupal\sample_search\Form\SampleSearchForm');

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $form = parent::blockForm($form, $form_state);

    $config = $this->getConfiguration();

    $form['sample_search_block_text'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Sub Heading'),
      '#description' => $this->t('Additional text for the Search Block'),
      '#default_value' => isset($config['sample_search_block_text']) ? $config['sample_search_block_text'] : '',
    );

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);
    $values = $form_state->getValues();
    $this->configuration['_search_block_text'] = $values['_search_block_text'];
  }

}
