<?php
/**
 * @file
 * Contains \Drupal\sample_search\Form\SampleSearchSettingsForm.
 */
namespace Drupal\sample_search\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class PeopleSearchSettingsForm.
 *
 * @package Drupal\sample_search\Form
 */
class PeopleSearchSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'sample_search.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'search_configuration_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('sample_search.settings');


    $form['sample_search_settings'] = array(
      '#type' => 'fieldset',
      '#title' => $this->t('Global Settings'),
      '#collapsible' => FALSE,
    );
    $form['sample_search_settings']['add_link'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Link to People Search from Search page.'),
      '#description' => $this->t('Check this to a link to Sample Search from the Search page.'),
      '#default_value' => $config->get('add_link'),
    ];
    $form['sample_search_settings']['max_results'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Maximum Number of Search Results'),
      '#description' => $this->t('This is the maximum number of search results to return at a time.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('max_results'),
    ];
    $form['sample_search_settings']['max_displayed'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Maximum Results to Display'),
      '#description' => $this->t('This is the maximum number of search results to display at a time.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('max_displayed'),
    ];

    $form['sample_search_settings']['directory'] = array(
      '#type' => 'fieldset',
      '#title' => $this->t('Sample Directory'),
      '#collapsible' => FALSE,
    );
    $form['sample_search_settings']['directory']['endpoint'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Endpoint'),
      '#description' => $this->t('This is the URL to the Sample Directory.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('endpoint'),
    ];
    $form['sample_search_settings']['directory']['appid'] = [
      '#type' => 'textfield',
      '#title' => $this->t('AppId'),
      '#description' => $this->t('Application ID for Directory.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('appid'),
    ];
    $form['sample_search_settings']['directory']['ip'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Directory IP Address'),
      '#description' => $this->t('This is the IP address for the Directory.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('ip'),
    ];
    $form['sample_search_settings']['sample_directory'] = array(
      '#type' => 'fieldset',
      '#title' => $this->t('Sample Directory'),
      '#collapsible' => FALSE,
    );
    $form['sample_search_settings']['sample_directory']['sample_endpoint'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Sample Directory Endpoint'),
      '#description' => $this->t('This is the URL to the Sample Directory.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('endpoint'),
    ];
    $form['sample_search_settings']['sample_directory']['user_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Sample Directory User ID'),
      '#description' => $this->t('This is the user id used to access the Sample Directory.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('user_id'),
    ];
    $form['sample_search_settings']['sample_directory']['user_pw'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Sample Directory Password'),
      '#description' => $this->t('This is the password used to access the Sample Directory.'),
      '#maxlength' => 255,
      '#size' => 64,
      '#default_value' => $config->get('user_pw'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $this->config('sample_search.settings')
      ->set('endpoint', $form_state->getValue('endpoint'))
      ->set('appid', $form_state->getValue('appid'))
      ->set('ip', $form_state->getValue('ip'))
      ->set('add_link', $form_state->getValue('add_link'))
      ->set('max_results', $form_state->getValue('max_results'))
      ->set('max_displayed', $form_state->getValue('max_displayed'))
      ->set('user_id', $form_state->getValue('user_id'))
      ->set('user_pw', $form_state->getValue('user_pw'))
      ->save();
  }

}
