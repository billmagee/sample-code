<?php
/**
 * @file
 * Contains \Drupal\sample_search\Form\PeopleSearchForm.
 */

namespace Drupal\sample_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\sample_search\SampleSearch;

class PeopleSearchForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'sample_search_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $sampleSearch = new SampleSearch();
    $params = $sampleSearch->getAllParameters();
    $search_type = $sampleSearch->getSearchType();
    if(!isset($institutions)) {
      $institutions = $sampleSearch->getSelectList('GetAffiliatedInstitutions', 'sample-select-list', '');
    }
    if(!isset($departments)) {
      $departments = $sampleSearch->getSelectList('GetDepartments', 'sample-select-list', '');
    }
    $form['search_type'] = array(
      '#markup' => '<div class="sample-search-filter-title">Staff</div>',
    );
    $form['LastName'] = array(
      '#type' => 'textfield',
      '#default_value' => (isset($params['LastName']) ? $params['LastName'] : ''),
      '#attributes' => array(
        'placeholder' => t('Last Name'),
        'title' => t("Enter a full or partial last name."),
      ),
    );
    $form['FirstName'] = array(
      '#type' => 'textfield',
      '#default_value' => (isset($params['FirstName']) ? $params['FirstName'] : ''),
      '#attributes' => array(
        'placeholder' => t('First Name'),
        'title' => t("Enter afull or partial first name."),
      ),
    );
    $form['Department'] = array(
      '#type' => 'select',
      '#default_value' => (isset($params['Department']) ? $params['Department'] : ''),
      '#options' => $departments,
      '#attributes' => array('placeholder' => t('Department')),
      '#empty_option' => '-- Select Department --',
      '#attributes' => array(
        'title' => t("Select a Department."),
      ),
    );
    $form['Institution'] = array(
      '#type' => 'select',
      '#default_value' => (isset($params['Institution']) ? $params['Institution'] : ''),
      '#options' => $institutions,
      '#empty_option' => '-- Select Institution --',
      '#attributes' => array(
        'placeholder' => t('Institution'),
        'title' => t("Select an institution."),
      ),
    );
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Search'),
    );
    $form['reset'] = array(
      '#type' => 'submit',
      '#value' => t('Clear All'),
    );
    $form['search_link']['change_information'] = array(
      '#markup' => '<hr class="sample-search-category"><div class="sample-people-search-link">
          <a href="https://some-url.com/page.asp?preferences.asp?mode=address" title="Link to preferences." target="_blank">
          Change Your Information
          </a>
        </div><hr class="sample-search-category">',
    );
    $form['search_link']['sample_search'] = array(
      '#markup' => '<div class="sample-search-link">To search directory,
          <a href="https://some-other-url.com/about/directories" title="Link to directories." target="_blank"> visit their site</a>
        </div><hr class="sample-search-category">',
    );

    // attach css
    $form['#attached']['library'][] = 'sample_people_search/samples_search.styles';

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Send form fields to search
    $params = $form_state->getValue('op') == 'Search' ? $form_state->getValues() : array();
    $form_state->setRedirect('sample_search.search', $params);
  }

}
