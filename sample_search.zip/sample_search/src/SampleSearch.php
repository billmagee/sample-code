<?php
namespace Drupal\sample_search;
use Drupal\Component\Utility\Xss;
use GuzzleHttp\Exception\RequestException;

/**
 * Class SampleSearch.
 *
 * Single centralized place for Sample Search helper funtions used by other classes.
 */
class SampleSearch {
  /**
   * get search type.
   */
   public function getSearchType() {
     $type = \Drupal::request()->query->get('search_type');

    return (isset($type) ? $type : 'faculty');
   }

  /**
   * Get the search terms parameters.
   */
  public function getAllParameters() {
    $query = \Drupal::request()->query->all();
    $params = array();

    foreach($query as $key => $value){
      $params[Xss::filter($key)] = Xss::filter($value);
    }

    return $params;
  }

  /**
   * Get search terms.
   */
  public function hasSearchTerms() {
    $params = $this->getAllParameters();
    $exclude = array('search_type', 'submit', 'reset',  'form_build_id', 'form_token', 'form_id', 'op');
    $temp = array();

    foreach($params as $key => $value){
        if(!in_array($key, $exclude) && !empty($value)) {
          return TRUE;
        }
    }

    return FALSE;
  }

  /**
   * Get search terms.
   */
  public function getSearchTerms() {
    $params = $this->getAllParameters();

    $exclude = array('search_type', 'submit', 'reset',  'form_build_id', 'form_token', 'form_id', 'op');
    $temp = array();

    foreach($params as $key => $value){
        if(!in_array($key, $exclude)) {
          $temp[$key] = $value;
        }
    }

    return $temp;
  }

  /**
   * Convert search terms to PascalCase.
   */
  public function convertToPascalCase($params = array()) {
    $temp = array();
    foreach($params as $key => $value){
      $temp_key = str_replace('_', '', ucwords($key, '_'));
      $temp[$temp_key] = $value;
    }

    return $temp;
  }

  /**
   * Convert search terms to PascalCase.
   */
  public function convertToCamelCase($params = array()) {
    $temp = array();
    foreach($params as $key => $value){
      $temp_key = lcfirst($key);
      $temp[$temp_key] = $value;
    }

    return $temp;
  }

  /**
   * Display get search results status.
   */
  public function getStatus($search_type) {
    $params = $this->getAllParameters();
    $status['terms'] = ($this->hasSearchTerms($params)) ? 'SUCCESS' : 'NO TERMS';
    $status['search_type'] = $search_type;

    return $status;
  }

  /**
   * Build query for http:Request.
   */
  public function getSearchUrl($op, $search_type) {
    $url = '';
    $pageNum = 0;
    $resultsPerPage = 10;

    switch ($search_type) {
      case 'alumni':
      case 'faculty':
      case 'select-list':
        $url = \Drupal::config('sample_search.settings')->get('endpoint') . $op;
        break;

      case 'connections':
        $url = \Drupal::config('sample_search.settings')->get('endpoint');
        break;

      default:
        break;
    }

    return $url;
  }

  /**
   * Build query for http:Request.
   */
  public function prepareQuery($op, $search_type, $params) {
    $user_info = NULL;
    $url = '';

    switch ($search_type) {
      case 'alumni':
      case 'faculty':
        // add additional parms to get data returned
        $params['GradYear'] = '';
        $params['City'] = '';
        $params['State'] = '';
        $params['Specialty'] = '';
        $params['strAppId'] = \Drupal::config('sample_search.settings')->get('appid');
        $params['strIPAddr'] = \Drupal::config('sample_search.settings')->get('ip');

        break;

      case 'select-list':
        // init params to what we need
        $params = array();
        $params['strAppId'] = \Drupal::config('sample_search.settings')->get('appid');
        $params['strIPAddr'] = \Drupal::config('sample_search.settings')->get('ip');

        break;

      case 'connections':
        $user_id = \Drupal::config('sample_search.settings')->get('user_id');
        $user_pw = \Drupal::config('sample_search.settings')->get('user_pw');

        // set options to include authentication and form params
        $options = [
          'auth' => [$user_id,$user_pw],
        ];

        return $options;
        break;

      default:
        break;
    }

    return array('form_params' => $params);
  }

  /**
   * Execute http:Request.
   */
  public function executeSearch($url, $query, $request = 'post') {

    // // if configuration is not set, display error
    // if(!isset($url)) {
    //   \Drupal::logger('sample_search')
    //     ->log(E_ERROR, 'Please update the configuration settings for Sample Search.');
    //   drupal_set_message('Please update the configuration settings for Sample Search.');
    // }

    $client = \Drupal::httpClient();

    try {
      $response = $client->$request($url, $query);
      $data = $response->getBody()->getContents();
      $json = json_decode($this->cleanData($data));
      if ($request == 'get') {
      }

      return $json;
    }
    catch (RequestException $e) {
      \Drupal::logger('sample_search')
        ->log(E_ERROR, 'url %url could not be fetched', ['%url' => $url]);
      drupal_set_message('Please make sure the configuration settings for SAmple Search have been set. Could not execute directory search.<br/>' . $e);
    }
  }

  /**
   * Clean data return by http:Request.
   */
  public function cleanData($data) {
    // this was need for the older api used with whitePapers
    $data = strip_tags($data);
    $data = str_replace("\n", "[NEWLINE]", $data);
    $data = preg_replace('/[^(\x20-\x7F)]*/', '', $data);
    $data = str_replace("[NEWLINE]", "\n", $data);

    return $data;
  }

  /**
   * Get select list.
   */
  public function getSelectList($op, $search_type, $params) {
    $url = $this->getSearchURL($op, $search_type);
    $query = $this->prepareQuery($op, $search_type, $params);
    $data = $this->executeSearch($url, $query, 'post');

    // set value to be same as option
    $arr = array();
    if($search_type == 'select-list') {
      $arr = $this->setSelectListValues($data);
    }

    return $arr;
  }

  /**
   * Set select list keys to be same as values.
   */
  public function setSelectListValues($data) {
    $arr = array();

    // set value to be same as option
    if(isset($data->departmentlist)) {
      foreach($data->departmentlist as $key => $value){
        $arr[$value] = $value;
      }
    } elseif ($data->institutionlist) {
      foreach($data->institutionlist as $key => $value){
        $arr[$value] = $value;
      }
    }

    return $arr;
  }

}
