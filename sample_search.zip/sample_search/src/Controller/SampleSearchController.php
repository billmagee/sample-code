<?php

namespace Drupal\sample_search\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\sample_search\SampleSearch;

const ALUMNI_SEARCH = 'SearchAlumni';
const ALUMNI_GET_DETAILS = 'GetAlumniPerson';
const FACULTY_SEARCH = 'SearchPersonAll';
const FACULTY_GET_DETAILS = 'GetPerson_StrEmail';

class SampleSearchController extends ControllerBase {

  /**
   * Perform Directory search.
   */
  public function search() {
    $sampleSearch = new SampleSearch();

    // get the search type from the parms
    $params = $sampleSearch->getSearchTerms();
    $search_type = $sampleSearch->getSearchType();
    $results = array();

    switch ($search_type) {
      case "alumni":
        $people = $this->getPeople(ALUMNI_SEARCH, $search_type, $params);
        $results = $this->getPeopleDetails(ALUMNI_GET_DETAILS, $search_type, $people);
        break;

      case "faculty":
        $people = $this->getPeople(FACULTY_SEARCH_PEOPLE, $search_type, $params);
        $results = $this->getPeopleDetails(FACULTY_GET_DETAILS, $search_type, $people);
        break;

      case "connections":
        // connections API gets all data at once, no topt level list (people) required
        $people = array();
        $results = $this->getPeopleDetails(OTHER_GET_DETAILS, $search_type, $people);
        break;

      default:
        break;
    }

    // return results
    $add_link = \Drupal::config('sample_search.settings')->get('add_link');
    $max_displayed = \Drupal::config('sample_search.settings')->get('max_displayed');
    $max_results = \Drupal::config('sample_search.settings')->get('max_results');
    $max_displayed = isset($max_displayed) ? $max_displayed : 5;
    $max_results = isset($max_results) ? $max_results : 25;

    $status = array(
      'terms' => $sampleSearch->hasSearchTerms($params),
      'search_type' => $search_type,
      'count' => count($people),
      'add_link' => (int)$add_link,
      'max_displayed' => (int)$max_displayed,
      'max_results' => (int)$max_results,
    );

    // Debug
    // $message = 'Max Display: ' . $max_displayed;
    // \Drupal::logger('sample-search')->notice($message);

    return $this->displayResults($search_type, $results, $status);
  }

  /**
   * Display perform search and return results.
   */
  public function getPeople($op, $search_type, $params) {
    if (!empty($params)) {
      $data = $this->getPeopleList($op, $search_type, $params);

      return $data;
    }

    return NULL;
  }

  /**
   * Get Person list based on search criteria.
   * (try to cache peopleList if possible)
   */
  public function getPeopleList($op, $search_type, $params) {
    $sampleSearch = new SampleSearch();
    $data = array();

    // execute search
    $url = $sampleSearch->getSearchURL($op, $search_type);
    $query = $sampleSearch->prepareQuery($op, $search_type, $params);
    $data = $sampleSearch->executeSearch($url, $query, 'post');

    return $this->buildPeopleList($op, $data);
  }

  /**
   * Process peopleList search results.
   * (To Do: try to cache peopleList if possible)
   */
  public function buildPeopleList($op, $data) {
    $results = array();

    // Process the results
    switch ($op) {
      case ALUMNI_SEARCH:
        foreach($data->alumnipersonlist as $key => $value){
          $results[$key] = $value;
        }
        break;
      case FACULTY_SEARCH:
        foreach($data->personlist as $key => $value){
          $results[$key] = $value;
        }
        break;
      case OTHER_SEARCH:
        break;

      default:
        break;
    }

    return $results;
  }

  /**
   * Person Details - get person details.
   */
  public function getPeopleDetails($op, $search_type, $people) {
    $sampleSearch = new SampleSearch();
    $results = array();
    $count = 0;
    $url = $sampleSearch->getSearchURL($op, $search_type);
    $maxResults = \Drupal::config('sample_search.settings')->get('max_results');

    switch ($search_type) {
      case "alumni":
      case "faculty":
        // build person details
        if(!empty($people) && !is_null($people)) {
          foreach($people as $person) {
            $count++;
            if ($count > (isset($maxResults) ? $maxResults : 100)) break;
            $query = $sampleSearch->prepareQuery($op, $search_type, array('Id' => $person->Id));
            $results[] = $sampleSearch->executeSearch($url, $query, 'post');
          }
        }
        break;

      case "connections":
        $params = $sampleSearch->getSearchTerms();
        $params = $sampleSearch->convertToCamelCase($params);
        $name = $params['firstName'] . '+' . $params['lastName'];
        $pageNum = 0;

        // remove elements we don't want to send to connections API
        unset($params['firstName']);
        unset($params['lastName']);
        unset($params['department']);
        unset($params['institution']);

        // need to pass params as part of the url, connections does not support form_params
        $url .= 'pageNum/' .$pageNum . '/resultsPerPage/' . $maxResults . '?name=' . $name;
        $url .= '&' . http_build_query($params, '', '&');
        $query = $sampleSearch->prepareQuery($op, $search_type, $params);
        $results['faculty'] = $sampleSearch->executeSearch($url, $query, 'get');

        break;

      default:
        break;
    }

    return $results;
  }

  /**
   * Display the search results.
   */
  public function displayResults($search_type, $results, $status) {

    switch ($search_type) {
      case 'alumni':
        return [
          '#theme' => 'alumni_search_results',
          '#content' => $results,
          '#status' => $status,
        ];
        break;
      case 'faculty':
        return [
          '#theme' => 'faculty_search_results',
          '#faculty' => $results,
          '#status' => $status,
        ];
        break;
      case 'connections':
        return [
          '#theme' => 'connections_search_results',
          '#content' => $results,
          '#status' => $status,
        ];
        break;
      default:
        return NULL;
        break;
    }
  }

}
