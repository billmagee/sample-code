(function ($) {
  $(document).ready(function () {

    // set search fields when page reloads
    setSearchFields();

    // show search fields
    $('#edit-search-type-sample, #edit-search-type-sample-connections').on('click', function() {
      setSearchFields();
    });

    // show more search results
    $("#sample-show-more").on("click", function() {
      var $lis = $(".sample-hidden:hidden");
      $lis.slice(0, 5).show();
      var size_li = $lis.length;
      var x = 5,
          start = 0;
      $('#next').click(function () {
          if (start + x < size_li) {
              $lis.slice(start, start + x).hide();
              start += x;
              $lis.slice(start, start + x).show();
          }
      });
      if(size_li <= x) {
        $("#sample-show-more").prop("disabled",true);
      }
    });
    function setSearchFields() {
      if ($('#edit-search-type-sample-alumni').is(':checked')) {
        $('#edit-department').hide();
        $('#edit-institution').hide();
        $('#edit-jobtitle').hide();
        $('#edit-departmentcode').hide();
        $('#edit-phonenumber').hide();
      }
      else if ($('#edit-search-type-sample-faculty').is(':checked')) {
        $('#edit-department').show();
        $('#edit-institution').show();
        $('#edit-jobtitle').hide();
        $('#edit-departmentcode').hide();
        $('#edit-phonenumber').hide();
      }
      else if ($('#edit-search-type-sample-connections').is(':checked')) {
        $('#edit-department').hide();
        $('#edit-institution').hide();
        $('#edit-jobtitle').show();
        $('#edit-departmentcode').show();
        $('#edit-phonenumber').show();
      }
      return;
    }


  });
})(jQuery);
